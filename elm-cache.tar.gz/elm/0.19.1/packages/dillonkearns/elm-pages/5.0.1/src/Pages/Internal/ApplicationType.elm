module Pages.Internal.ApplicationType exposing (ApplicationType(..))


type ApplicationType
    = Browser
    | Cli
